#include "glshim.h"

int initOpenGL(int device_id) {
    return 1;
}

int setOpenGLBufferSize(int width, int height) {
    return 1;
}

void closeOpenGL() {
}
