#ifndef __GLSHIM_H__
#define __GLSHIM_H__

int initOpenGL(int device_id);
void closeOpenGL();
int setOpenGLBufferSize(int width, int height);

#endif
